# coding=utf-8
# ---------------------------------------------------------------
# Desenvolvedor:    Arannã Sousa Santos
# Mês:              12
# Ano:              2015
# Projeto:          pagseguro_xml
# e-mail:           asousas@live.com
# ---------------------------------------------------------------

from .test_detalhes_v3 import ClasseTransacaoDetalhesTest
from .test_historico_v2 import ClasseTransacaoHistoricoTest
from .test_abandonadas_v2 import ClasseTransacaoAbandonadasTest