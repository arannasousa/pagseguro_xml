# coding=utf-8
# ---------------------------------------------------------------
# Desenvolvedor:    Arannã Sousa Santos
# Mês:              12
# Ano:              2015
# Projeto:          pagseguro_xml
# e-mail:           asousas@live.com
# ---------------------------------------------------------------

from .test_pagamento_v2 import ClassePagamentoCheckoutV2Test, ClassePagamentoRetornoCheckoutV2Test
from .test_erros_v2 import ClassePagamentoErrosV2Test
