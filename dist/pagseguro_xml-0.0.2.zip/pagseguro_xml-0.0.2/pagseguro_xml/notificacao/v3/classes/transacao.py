# coding=utf-8
# ---------------------------------------------------------------
# Desenvolvedor:    Arannã Sousa Santos
# Mês:              12
# Ano:              2015
# Projeto:          pagseguro_xml
# e-mail:           asousas@live.com
# ---------------------------------------------------------------

from ....consultas.v3.classes.detalhes import ClasseTransacaoDetalhes as __transacao__


class ClasseNotificacaoTransacao(__transacao__):
    """
    A classe da CONSULTA é exatamente a mesma que preciso aqui
    """
    pass