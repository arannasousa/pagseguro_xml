# coding=utf-8
# ---------------------------------------------------------------
# Desenvolvedor:    Arannã Sousa Santos
# Mês:              12
# Ano:              2015
# Projeto:          pagseguro_xml
# e-mail:           asousas@live.com
# ---------------------------------------------------------------

from .v3 import ApiPagSeguroNotificacao as ApiPagSeguroNotificacao_v3, CONST as CONST_v3